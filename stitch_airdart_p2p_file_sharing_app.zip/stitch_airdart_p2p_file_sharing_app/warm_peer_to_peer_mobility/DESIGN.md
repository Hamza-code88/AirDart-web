---
name: Warm Peer-to-Peer Mobility
colors:
  surface: '#fff8f1'
  surface-dim: '#e2d9c9'
  surface-bright: '#fff8f1'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#fcf2e2'
  surface-container: '#f7eddc'
  surface-container-high: '#f1e7d6'
  surface-container-highest: '#ebe1d1'
  on-surface: '#1f1b11'
  on-surface-variant: '#554242'
  inverse-surface: '#353025'
  inverse-on-surface: '#f9f0df'
  outline: '#887271'
  outline-variant: '#dac1bf'
  surface-tint: '#994345'
  primary: '#994345'
  on-primary: '#ffffff'
  primary-container: '#ff9494'
  on-primary-container: '#782a2d'
  inverse-primary: '#ffb3b2'
  secondary: '#785656'
  on-secondary: '#ffffff'
  secondary-container: '#fdcfcf'
  on-secondary-container: '#795657'
  tertiary: '#6e5a58'
  on-tertiary: '#ffffff'
  tertiary-container: '#c5acab'
  on-tertiary-container: '#52403f'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdad9'
  primary-fixed-dim: '#ffb3b2'
  on-primary-fixed: '#400108'
  on-primary-fixed-variant: '#7b2c2f'
  secondary-fixed: '#ffdad9'
  secondary-fixed-dim: '#e8bcbc'
  on-secondary-fixed: '#2d1415'
  on-secondary-fixed-variant: '#5e3e3f'
  tertiary-fixed: '#f8dcda'
  tertiary-fixed-dim: '#dbc0bf'
  on-tertiary-fixed: '#261817'
  on-tertiary-fixed-variant: '#554241'
  background: '#fff8f1'
  on-background: '#1f1b11'
  surface-variant: '#ebe1d1'
typography:
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 26px
    fontWeight: '700'
    lineHeight: 34px
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 15px
    fontWeight: '600'
    lineHeight: 20px
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 13px
    fontWeight: '600'
    lineHeight: 18px
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.5px
rounded:
  sm: 0.5rem
  DEFAULT: 1rem
  md: 1.5rem
  lg: 2rem
  xl: 3rem
  full: 9999px
spacing:
  gutter: 1rem
  margin: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1rem
  space-xl: 1.5rem
---

## Brand & Style

This design system establishes a warm, intimate, and effortlessly fluid peer-to-peer sharing experience. Departing from clinical, cold tech utilities, the visual language draws on tactile warmth and physical paper metaphors—symbolized by clean paper plane and dart motifs gliding smoothly across local networks. 

The aesthetic is soft minimalism: generous whitespace, pastel warmth, organic rounded forms, and approachable clarity. It eliminates intimidation from local networking and file transfers by treating local Wi-Fi data exchange as an immediate, friendly gesture. The experience evokes calm confidence, effortless connectivity, and tactile hospitality while maintaining strict technical precision.

## Colors

The palette relies entirely on a dedicated light-mode scheme with creamy canvas tones and warm coral-rose accents. 

### Palette Application
- **Base Canvas (`#FFF5E4`):** Applied uniformly to the viewport background across all screens to create an unbroken, inviting foundation.
- **Primary Accent (`#FF9494`):** Used for focused interactive states, primary action buttons, active tab indicators, progress indicators, toggles, and status icons.
- **Soft Secondary (`#FFD1D1`):** Applied to active chips, standard card backgrounds, selected file containers, and inactive progress tracks.
- **Light Tint (`#FFE3E1`):** Designated for passive text inputs, pressed component states, and subtle section separators.
- **Typography Tokens:**
  - Primary Content: `#3B2A2A` (deep warm roast) for high legibility across headings, primary body, and active icons.
  - Secondary Content: `#7A6363` (soft cocoa) for metadata, captions, device connection statuses, and inactive elements.

### Legibility Rule
White text (`#FFFFFF`) is strictly forbidden over pastel backgrounds (`#FF9494`, `#FFD1D1`, `#FFE3E1`, `#FFF5E4`). All typographic labels and vector icons rendered on pastel surfaces must use `#3B2A2A` to preserve contrast and visual cohesion.

## Typography

The type system blends the energetic curves of **Plus Jakarta Sans** for display headings, navigational wayfinding, and interactive buttons with the clinical clarity of **Inter** for file metadata, transfer metrics, and running copy.

Text elements are styled with deliberate vertical breathing room. Large headings establish friendly immediacy, while strict tracking is maintained for compact data chips, transmission rates, and status tags to ensure glanceable clarity on 390px mobile screens.

## Layout & Spacing

Designed primarily for standard 390px mobile display widths with full multi-platform adaptability. The layout architecture uses a 4-column fluid mobile grid anchored by consistent 20px (`1.25rem`) outer screen margins and 16px (`1rem`) column gutters.

### Geometry & Spatial Rhythm
- **Touch Target Floor:** All tap zones are built with a rigid minimum dimension of 48×48px.
- **Vertical Hierarchy:** Content chunks stack with 16px (`space-lg`) default margins, increasing to 24px (`space-xl`) between major conceptual regions (e.g., Radar Scanner zone to Active Session queue).
- **Safe Area Adaptability:** The layout extends edge-to-edge with the base color `#FFF5E4`, locking persistent floating nav components 16px above the device home indicator.

## Elevation & Depth

Visual separation relies on warm tonal layering complemented by ultra-soft, warm-tinted ambient dropshadows. Crisp black drop shadows and stark borders are entirely excluded.

- **Level 0 (Canvas Base):** Plain `#FFF5E4` surface.
- **Level 1 (Subtle Containers & Surface Rows):** `#FFE3E1` surface fill with no shadow. Used for text entry fields, inactive list groupings, and inset zones.
- **Level 2 (Standard Elevated Cards & Floating Sheets):** `#FFD1D1` surface with a diffuse, warm drop shadow: `box-shadow: 0 4px 20px -2px rgba(122, 99, 99, 0.08)`.
- **Level 3 (Primary CTAs & Active Floating Radar):** `#FF9494` with an ambient glow: `box-shadow: 0 6px 24px rgba(255, 148, 148, 0.35)`.
- **Focus / Pressed Treatment:** Components compress slightly (`scale(0.98)`) and shift background tones toward `#FFE3E1` without hard focus rings.

## Shapes

The shape hierarchy combines smooth capsule pills with rounded nested containers. Fully pill-shaped geometries (`9999px`) govern all interactive touch elements—buttons, filter chips, network search toggles, and status tags. 

Cards and content containers adhere to a softened 20px–24px corner radius (`rounded-xl` to `rounded-2xl`). This curvature harmonizes with hardware display corners on contemporary iOS and Android viewports, giving transfer cards and radar containers an organic feel.

## Components

### Buttons & CTAs
- **Primary Button:** Pill-shaped (`rounded-full`), minimum 48px height. Fill is `#FF9494`, content (text/outlined dart icon) is strictly `#3B2A2A`. Subtle warm glow on rest, settling to `#FFE3E1` on active press.
- **Secondary / Ghost Button:** Pill-shaped, fill `#FFE3E1`, label `#3B2A2A`. Inactive states take an outline of `1.5px solid #FFD1D1` over `#FFF5E4`.

### Radar & Device Discovery
- **Discovery Grid:** Concentric pulse circles drawn in `1.5px solid #FFD1D1` centered on a pulsating user node.
- **Peer Device Avatar:** 64×64px pill-circle container filled with `#FFD1D1`, featuring a centered outlined device or paper-plane motif in `#3B2A2A`, captioned with `label-md` device names.

### Cards & Transfer Items
- **Transfer Card:** Background `#FFD1D1`, 20px corner radius, 16px internal padding. 
- **Progress System:** Inactive track colored `#FFF5E4` (or `#FFE3E1`), active fill bar colored `#FF9494`, with transfer speeds rendered in `body-sm` (`#7A6363`).
- **Clipboard Card:** Inset background `#FFE3E1`, rounded at 16px, featuring an instant "Send" or "Copy" pill action on the trailing edge.

### Chips & Filter Tabs
- **Action Chips:** 36px height, pill-shaped. Inactive chips use a transparent base with a `1.5px solid #FFD1D1` border and `#7A6363` text. Active chips take full `#FFD1D1` background with `#3B2A2A` text.

### Form Inputs & Text Fields
- **Input Field:** Height 48px, fully rounded (24px radius) or 16px soft radius. Background `#FFE3E1`, borderless in resting state. Text is `#3B2A2A`, placeholder is `#7A6363`. Active focus introduces an inner stroke of `1.5px solid #FF9494`.

### Navigation
- **Bottom Navigation Bar:** Floating dock resting 16px above the viewport base, encased in a 32px curved capsule shell filled with `#FFF5E4` and supported by Level 2 warm ambient shadowing. 
- **Navigation Tabs:** Four destinations (Home, Transfers, Clipboard, Settings). Inactive tabs render in `#7A6363`; the active tab features a `#FF9494` background pill containing the outlined icon and high-contrast `#3B2A2A` typography.